 <?php include("../content/start.php"); ?>

<html lang="en">
    <head>
      
     
  <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <link href="http://css.egtema3y.com/bootstrap.min.css" rel="stylesheet">
    <link href="http://css.egtema3y.com/bootstrap-responsive.min.css" rel="stylesheet">
    <link href="http://css.egtema3y.com/egtema3y.css" rel="stylesheet">


    <script src="http://js.egtema3y.com/jquery.js"></script>
    <script src="http://js.egtema3y.com/bootstrap.min.js"></script>
    <script src="http://js.egtema3y.com/jquery.base64.js"></script>
    <script src="http://js.egtema3y.com/jquery.tmpl.js"></script>
      <script src="http://js.egtema3y.com/egtema3y.js"></script>
  
    </head>
    <body>
         <?php include("js/analyticstracking.html"); ?>
        <?php include("shared/site-logo.html"); ?>
		 <?php include("shared/mainmenu.html"); ?>
		   <br/><br/><br/><br/><br/><br/>
		
		
		
		
		<div class="row-fluid">
		
		<div class="span3 "> <?php include("shared/addons.html"); ?> </div>
		<div class="span9">
             <?php include("shared/chatroomsview.html"); ?> 
           
             </div>
		
		
		</div>
		
   

<br/><br/><br/>
                       
        <!--<div class="row-fluid statusbar btn-warning">
            <div class='span6 offset3' id="statusinfodiv">
                 <?php echo include("shared/end.php"); ?>
            </div>
        </div>        -->

    </body>
</html>

