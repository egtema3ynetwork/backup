<?php

 header("Location: http://egtema3y.com/sites/myfacebook");

?>
