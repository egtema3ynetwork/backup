<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">

   <link href="bootstrap.min.css" rel="stylesheet">
    <link href="bootstrap-responsive.min.css" rel="stylesheet">

    <script src="jquery.js"></script>
    <script src="bootstrap.min.js"></script>



    <style>
        
        .shadow {
    padding: 5px;
    -moz-box-shadow: 0 4px 8px rgba(0,0,0,0.5);
    -webkit-box-shadow: 0 4px 8px rgba(0,0,0,0.5);
    box-shadow: 0 4px 8px rgba(0,0,0,0.5);

    -webkit-border-radius: 5px;
-moz-border-radius: 5px;
border-radius: 5px;

}
        
    </style>
</head>
    
    <body>
        <center>
        <div class="row"  style="height:30px;background: #333"></div>
        <hr>
     
        <div class="row-fluid" style="direction: rtl;">
            
            
            <p  style="font-size: xx-large;" >
            السلام عليكم ورحمة الله وبركاته
            </p><br>
            
            
      <p  style="font-size: large;">
         
يسعدنا أن نقدم لكم تطبيق فيسبوكى للتفاعل والتكامل مع الفيسبوك 
            </p><br>
                <a href="app_register.php" class="btn btn-primary shadow"  style="width: 200px;font-size: large">
         اشترك الان بالتطبيق
                 </a><br><br>
            
        
            
            
            
        </div>
        
            <br><br>
            <div class="row-fluid" >
                <a href="http://www.egtema3y.com" class="btn btn-inverse shadow"  target="_blank" style="width: 200px;font-size: large">
                ندعوك لزيارة موقعنا
                </a>
                 <a href="https://www.facebook.com/Egtema3yNetwork" class="btn btn-primary shadow" target="_blank" style="width: 200px;font-size: large">
                     تابع صفحتنا على الفيسبوك
                 </a>
                  <a href="https://twitter.com/Egtema3yNetwork" class="btn btn-info shadow" target="_blank" style="width: 200px;font-size: large">
                      تابع حسابنا على تويتر
                  </a>
                  
            </div>
        
    </center>
    </body>
    
</html>
