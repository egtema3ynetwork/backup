<?php

define('DB_SERVER', 'localhost');
define('DB_USER', 'egypt');
define('DB_PASSWORD', '32733273');
define('DB_NAME', 'apps');
define('TABLE_NAME', 'facebooky_users');



define('APP_ID', '555334907846944');    //	فيسبوكى

define('APP_SECRET', '4ba669bf5429978abf9540430916cb51');
define('APP_SCOPE', 'email,user_about_me,user_birthday,user_groups,user_hometown,user_likes,user_location,user_notes,user_photos,user_status,friends_about_me,friends_birthday,friends_groups,friends_hometown,friends_likes,friends_location,friends_notes,friends_photos,friends_status,publish_actions,manage_pages,publish_stream,read_mailbox,read_page_mailboxes,read_stream,export_stream,status_update,photo_upload,video_upload,create_note,share_item,xmpp_login,sms,read_friendlists,manage_friendlists,read_requests,manage_notifications,read_insights,publish_checkins');

define('APPACCESSTOKEN', '555334907846944|g43hVmwWLxqawGBNkgfEzde7cpU');//https://graph.facebook.com/oauth/access_token?client_id=555334907846944&client_secret=4ba669bf5429978abf9540430916cb51&grant_type=client_credentials

define('GOURL', 'http://facebooky.egtema3y.com/faceprofile.php');



?>

