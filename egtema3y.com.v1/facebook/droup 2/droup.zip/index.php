<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<html>
  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">

   <link href="http://egtema3y.com/css/bootstrap.min.css" rel="stylesheet">
    <link href="http://egtema3y.com/css/bootstrap-responsive.min.css" rel="stylesheet">

    <script src="http://code.jquery.com/jquery.js"></script>
    <script src="http://egtema3y.com/js/bootstrap.min.js"></script>


</head>
    
    <body>
        <center>
        <div class="row"  style="height:30px;background: #333"></div>
        <hr>
     
        <div class="row-fluid" style="direction: rtl;">
            
            
            <p  style="font-size: xx-large;" >
            السلام عليكم ورحمة الله وبركاته
            </p><br>
            
            
      <p  style="font-size: large;">
         
يسعدنا أن نقدم لكم تطبيق دروب الخير من موقع دروب , لنشر الوعي الإسلامي , والأذكار , والسنن النبوية
            </p><br>
                <a href="app_register.php" class="btn btn-primary shadow"  style="width: 200px;font-size: large">
         اشترك الان بالتطبيق
                 </a><br><br>
            
                  <p  style="font-size: large;">
           وسلسلة حصرية من الأقوال والمواضيع المختصرة المميزة , التي تفيد القارئ وتكون لك في ميزان حسناتك لكل من يقرؤها
            </p>
            
                  <p  style="font-size: large;">
         بالإضافة إلى التذكير بسنن الحبيب عليه الصلاة والسلام , وخاصة المهجورة
            </p>
            
                  <p  style="font-size: large;">
           بعد اشتراكك بالتطبيق يصلك تلقائيًا على ملفك كل ما سيكون لك أجرٌ وثواب في حياتك 
            </p>
            
                  <p  style="font-size: large;">
           نسال الله التوفيق لنا ولكم ولسائر المسلمين يا رب
            </p>
            
           
            
            
            
        </div>
        
            <br><br>
            <div class="row-fluid" >
                <a href="http://www.droup.net/vb" class="btn btn-inverse shadow"  target="_blank" style="width: 200px;font-size: large">
                ندعوك لزيارةموقعنا
                </a>
                 <a href="https://www.facebook.com/droup.net" class="btn btn-primary shadow" target="_blank" style="width: 200px;font-size: large">
                     تابع صفحتنا على الفيسبوك
                 </a>
                  <a href="https://twitter.com/droup_net" class="btn btn-info shadow" target="_blank" style="width: 200px;font-size: large">
                      تابع حسابنا على تويتر
                  </a>
                  
            </div>
        
    </center>
    </body>
    
</html>
