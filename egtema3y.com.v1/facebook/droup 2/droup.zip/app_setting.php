<?php
 require 'setting.php';
 require 'shared/functions.php';


$con = mysql_connect(DB_SERVER, DB_USER, DB_PASSWORD);
mysql_set_charset('utf8', $con);




?>

