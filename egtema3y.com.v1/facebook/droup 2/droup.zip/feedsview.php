<html>
<head>

      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimum-scale=1.0, maximum-scale=1.0">
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">

    <link href="http://css.egtema3y.com/bootstrap.min.css" rel="stylesheet">
    <link href="http://css.egtema3y.com/bootstrap-responsive.min.css" rel="stylesheet">
    <link href="http://css.egtema3y.com/egtema3y.css" rel="stylesheet">


    <script src="http://js.egtema3y.com/jquery.js"></script> 
    <script src="http://js.egtema3y.com/jquery.tmpl.js"></script>

    <script src="http://js.egtema3y.com/bootstrap.min.js"></script>
    <script src="http://js.egtema3y.com/jquery.base64.js"></script>
    <script src="http://js.egtema3y.com/egtema3y.js"></script>
   
   
  
  
</head>
     <body >
         <center>
     

          <br> 
          
         <div class="row-fluid">
                 <div class=" span10 offset1 btn-inverse " style="height: 20px;">    </div><br><br>
           <div id="TT_info"  class="span6 offset3 label label-inverse"> </div>

   <div id="divcontent1" class="span8 offset2"> <?php include ("myfeeds.tmp.html");?></div>
             </div>

         <script>
             $( document ).ready( function ()
{
    loadmyfacebookfeeds();
});

            
         </script>

     </center>
    </body>
</html>
