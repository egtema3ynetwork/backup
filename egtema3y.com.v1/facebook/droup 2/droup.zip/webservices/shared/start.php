<?php

	set_time_limit(0);
// put this at the top of your page/script
$exectime = microtime();
$exectime = explode(" ", $exectime);
$exectime = $exectime[1] + $exectime[0];
$starttime = $exectime;

?>
