<?php

$setting = array();
$setting['developerName'] = "amr barakat";



function spy($data)
{
    return base64_encode($data);
}

function unspy($data)
{
   return base64_decode($data);
}




?>
